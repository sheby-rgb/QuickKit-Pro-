QUICKKIT — 10 TOOLS UPGRADE

Included tools:
1. Image Compressor
2. Image Resizer
3. JPG to PNG
4. PNG to JPG
5. Image to PDF
6. Merge PDFs
7. Extract PDF Page
8. Rotate PDF
9. Word & Character Counter
10. Text Case Converter

HOW TO UPDATE YOUR GITHUB PAGES WEBSITE
1. Download and extract this ZIP on your phone or computer.
2. Open your GitHub repository: quickkit-tools.
3. Upload the new index.html file to the repository root.
4. If GitHub says index.html already exists, choose the option to replace it.
5. Commit the changes. Wait a few minutes, then refresh your live website.

Notes:
- PDF tools load PDF-Lib from a CDN, so an internet connection is required.
- These are client-side tools; test them with non-sensitive sample files first.
- This ZIP does not include Privacy Policy, Terms, About, or Contact pages. Add genuine pages and useful original content before applying for advertising approval.
